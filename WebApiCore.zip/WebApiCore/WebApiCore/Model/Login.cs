﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCore.Model
{
    public class Login
    {
        public string username { get; set; }
        public string passsword { get; set; }
    }
}
